#!/bin/sh
set -eu
cd "$(dirname "$0")"
if [ "$(id -u)" != 0 ]; then echo "Run with sudo to install the service." >&2; exit 1; fi
if [ -f sentinelgrid-server ]; then role=server; else role=agent; fi
if [ "$role" = agent ] && [ "$#" -gt 0 ]; then
 case "$1" in https://*|http://127.0.0.1:*) ;; *) echo "Expected HTTPS server URL" >&2; exit 1;; esac
 case "$1" in *[!a-zA-Z0-9./:_-]*) echo "Use a simple DNS name and optional port" >&2; exit 1;; esac
 case "${2:-}" in *[!0-9,]*) echo "Expected comma-separated port numbers" >&2; exit 1;; esac
 if [ -t 0 ]; then echo "Redirect a private host key file into this command." >&2; exit 1; fi
fi
service=sentinelgrid-$role
account=$service
if ! getent passwd "$account" >/dev/null; then
 useradd --system --user-group --home-dir "/var/lib/$service" --shell /usr/sbin/nologin "$account"
fi
install -d -m 0750 -o root -g "$account" "/etc/$service"
install -d -m 0700 -o "$account" -g "$account" "/var/lib/$service"
install -m 0755 "$service" "/usr/local/bin/$service.new"
mv -f "/usr/local/bin/$service.new" "/usr/local/bin/$service"
install -m 0644 "$service.service" "/etc/systemd/system/$service.service"
if [ ! -e "/etc/$service/config" ]; then install -m 0640 -o root -g "$account" config.example "/etc/$service/config"; fi
if [ "$role" = agent ] && [ "$#" -gt 0 ]; then
 directory=/etc/$service
 umask 077
 tmp=$(mktemp "$directory/.key-XXXXXX")
 trap 'rm -f "$tmp"' EXIT
 cat > "$tmp"
 if ! grep -Eq '^[a-zA-Z0-9_-]+\.[a-zA-Z0-9_-]+\.[A-Za-z0-9_-]{43}$' "$tmp" || [ "$(wc -c < "$tmp")" -gt 180 ]; then echo "Invalid host key." >&2; exit 1; fi
 chown "$account:$account" "$tmp"
 mv "$tmp" "$directory/agent.key"
 tmp=$(mktemp "$directory/.config-XXXXXX")
 printf 'SERVER=%s\nPORTS=%s\n' "$1" "${2:-}" > "$tmp"
 chown "root:$account" "$tmp"
 chmod 0640 "$tmp"
 mv "$tmp" "$directory/config"
fi
systemctl daemon-reload
if [ "$role" = server ] || [ -s "/etc/$service/agent.key" ]; then
 systemctl enable "$service"
 systemctl restart "$service"
else
 echo "Installed $service. Supply the server URL and host key to enable monitoring."
fi
